// This is a generated file. Not intended for manual editing.
package com.goide.psi;

import java.util.List;
import org.jetbrains.annotations.*;
import com.intellij.psi.PsiElement;
import com.intellij.psi.StubBasedPsiElement;
import com.goide.stubs.GoLabelDefinitionStub;

public interface GoLabelDefinition extends GoNamedElement, StubBasedPsiElement<GoLabelDefinitionStub> {

  @NotNull
  PsiElement getIdentifier();

}
