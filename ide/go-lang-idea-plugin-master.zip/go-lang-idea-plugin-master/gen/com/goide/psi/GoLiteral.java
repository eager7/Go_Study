// This is a generated file. Not intended for manual editing.
package com.goide.psi;

import java.util.List;
import org.jetbrains.annotations.*;
import com.intellij.psi.PsiElement;

public interface GoLiteral extends GoExpression {

  @Nullable
  PsiElement getChar();

  @Nullable
  PsiElement getDecimali();

  @Nullable
  PsiElement getFloat();

  @Nullable
  PsiElement getFloati();

  @Nullable
  PsiElement getHex();

  @Nullable
  PsiElement getInt();

  @Nullable
  PsiElement getOct();

}
